// Import required packages
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const bodyParser = require('body-parser');
const userRoutes = require('./routes/userRoutes');  // Import your user routes file
const resourceRoutes = require('./routes/resourceRoutes');  // Import resource-related routes

// Load environment variables from the .env file
dotenv.config();

// Initialize the app
const app = express();

// Middleware
app.use(cors());  // Enables cross-origin requests (CORS)
app.use(express.json());  // Parse JSON bodies
app.use(bodyParser.urlencoded({ extended: true }));  // Parse URL encoded data

// MongoDB connection
const connectDB = async () => {
    try {
        console.log("Connecting to MongoDB...");
        await mongoose.connect(process.env.MONGO_URI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
        console.log('MongoDB connected successfully');
    } catch (error) {
        console.error('Error connecting to MongoDB:', error.message);
        process.exit(1);  // Exit the process if the connection fails
    }
};

// Connect to DB
connectDB();

// Routes
app.use('/api/users', userRoutes);  // User-related routes (CRUD, profile, etc.)
app.use('/api/resources', resourceRoutes);  // Resource-related routes (CRUD, resource fetch)

// Default route to test server
app.get('/', (req, res) => {
    res.send('Welcome to the Readify Backend!');
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
