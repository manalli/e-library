// models/User.js

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

// Create user schema
const userSchema = new mongoose.Schema(
  {
    userFullName: {
      type: String,
      required: true,
      unique: true, // Ensures unique names, you can remove this based on requirements
    },
    age: {
      type: Number,
      required: false,
    },
    gender: {
      type: String,
      required: false,
    },
    dob: {
      type: String,
      required: false,
    },
    address: {
      type: String,
      default: '',
    },
    mobileNumber: {
      type: Number,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      maxLength: 50,
    },
    password: {
      type: String,
      required: true,
      minLength: 6,
    },
    activity: {
      ratings: [
        {
          materialId: mongoose.Schema.Types.ObjectId,
          rating: Number,
        },
      ],
      views: [
        {
          materialId: mongoose.Schema.Types.ObjectId,
        },
      ],
      downloads: [
        {
          materialId: mongoose.Schema.Types.ObjectId,
        },
      ],
    },
  },
  { timestamps: true } // Automatically adds createdAt and updatedAt fields
);

// Pre-save hook for hashing password
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10); // Hashing password with salt rounds of 10
  next();
});

// Method to compare passwords
userSchema.methods.comparePassword = async function (password) {
  return await bcrypt.compare(password, this.password);
};

// Fix: Check if the model already exists before creating it
module.exports = mongoose.models.User || mongoose.model('User', userSchema);
