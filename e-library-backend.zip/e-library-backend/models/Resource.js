// models/Resource.js
const mongoose = require('mongoose');

// Define the schema for the resource
const resourceSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    subject: {
        type: String,
        required: true
    },
    fileUrl: {
        type: String,
        required: true
    },
    views: {
        type: Number,
        default: 0
    },
    paid: {
        type: Boolean,
        default: false
    },
    image: {
        type: String
    },
    author: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    }
}, {
    timestamps: true
});

// Create and export the model
const Resource = mongoose.model('Resource', resourceSchema);
module.exports = Resource;
