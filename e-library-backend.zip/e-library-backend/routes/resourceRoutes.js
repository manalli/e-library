const express = require('express');
const Resource = require('../models/Resource');
const router = express.Router();

// Create a new resource
router.post('/', async (req, res) => {
  try {
    const newResource = new Resource(req.body);
    await newResource.save();
    res.status(201).json(newResource);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get all resources
router.get('/', async (req, res) => {
  try {
    const resources = await Resource.find();
    res.json(resources);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Search resources
router.get('/search', async (req, res) => {
  try {
    const { query } = req.query;
    if (!query) {
      return res.status(400).json({ message: 'Query is required' });
    }

    const resources = await Resource.find({
      title: { $regex: query, $options: 'i' },
    });

    if (resources.length === 0) {
      return res.status(404).json({ message: 'No resources found' });
    }

    res.json(resources);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
